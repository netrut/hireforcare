<?php

require('../../db.php');

// print_r($_POST);
echo "ok";
?>